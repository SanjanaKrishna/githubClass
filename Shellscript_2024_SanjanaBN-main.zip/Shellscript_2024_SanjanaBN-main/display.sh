#!/bin/bash
echo -e "Welcome everybody \nThis is Earth\n"
echo "$0"
