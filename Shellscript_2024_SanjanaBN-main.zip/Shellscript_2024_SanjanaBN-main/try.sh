#!/bin/bash
echo "$0"
