#!/bin/bash

n1=2
n2=3
s1="Radhe Radhe"

echo "The 1st num is $n1 , the 2nd num is $n2 , String is $s1"

echo "Input 3rd num:"
read n3

echo "Input the CAPTCHA"
read s2

echo "The number and String mentioned are $n3 and $s2"
