echo "name:$hostname"








echo "The Server name is $HOSTNAME"
