#!/bin/bash
echo "Enter the number:"
read num
if [ "$num" == "Sanjana" ] || [ "$num" == "sanjana" ]
then 
  echo "Right"
else
  echo "$num is wrong"
fi


	
